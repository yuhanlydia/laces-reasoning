# LaLaLanD manuscript plan

Title: LaLaLanD: Linear-Attention Latent Language Diffusion Models
Scope: New 9-page main paper plus bibliography and appendix. This is the generative-architecture paper, not LATTICE RL.

Core claim: use linear-attention latent diffusion to generate native memory, making global, recurrent-refresh, and conditionally independent parallel-agent rendering selectable execution schedules.

Three experimental questions
1. Compute / scheduling: matched dense-DiT prior, raw recurrent AR, Transformer AR; incremental training cost, end-to-end latency, peak memory and matched quality.
2. Long-context understanding: fixed evidence and answer budgets; RACE, LongBench QA, bAbILong and RULER; raw recurrent/SSM and Qwen baselines. Long generation is a separate secondary task.
3. Model quality: shared input/output evaluation for AR, continuous latent diffusion (CoLA), continuous embedding flow (ELF), and discrete diffusion. No cross-source numbers silently pooled.

Ablations: fixed vs dynamic writer at matched capacity, latent dimension, global vs refresh vs parallel, LA vs dense prior, posterior vs sampled plans, S0 data/objective and sampler.

Evidence ledger
- Technical_Report.pdf: legacy fixed-basis architecture, global/chunked framework, baseline roster. Its numerical results are NOT migrated to the new tables.
- Current repository: dynamic writer factorization uses per-layer flattened U and shared-across-head V; not independent V per head.
- New parallel-agent contract: complete independent cache plus known launch anchor. Alpha=1 on recurrent matrices alone does not prove independence. Explicit target evaluation, not a claim of verified current implementation.
- Current paper contains no new experimental performance values. Table cells blank by request.
- CoLA/ELF descriptions grounded in primary papers, not the older report's overgeneralization that all methods are prefix tuning.

Figures
1. Three generation interfaces, structural schematic; no invented result curves.
2. Editable method overview: compact VAE training branch, bidirectional LA prior, dynamic writer, global and parallel renderers.
3. Serialized versus parallel execution under the same sealed boundary; analytical schedule only.

Main prose: ambitious but bounded, no fabricated achievements; hypotheses interpreted in experiment subsections. Appendix: full state-boundary proof, loss/protocol details, datasets, baseline registry, additional blank tables, reproducibility.
