# Source and claim map

## User material
`Technical_Report.pdf`: old state-hijacking/LACES report. Used for the global/trajectory distinction, compact coordinate/state interface, and baseline names (RWKV-7, Qwen2.5-3B, Llama-3.2-3B, RWKV-6). The old numerical results and timing statements are not reused as results for the new system. The report does not establish the new sealed-start parallel implementation.

`yuhanlydia/laces-reasoning` at `ef3a7cd034f4795f6c6f42a9afc883fcb64e6879`, `models/state_hijacking_dit.py`, lines 1110–1140: active fixed/dynamic writer dispatch; flattened per-layer U, per-layer V shared across heads; scalar state_scale. Appendix B records this exact special case.

## Public primary research
- CoLA-DLM: https://arxiv.org/html/2605.06548v1 — Text VAE, block-causal DiT, eight-task table organization, distinction between generation and likelihood. Structural table organization was adapted, not its measured values.
- ELF: https://arxiv.org/html/2605.10938v1 — continuous contextual embeddings, shared denoiser/decoder, OWT generation, WMT14/XSum, B/M/L configurations. The manuscript does not call it a native-state writer or claim its reported QA results.
- DREAMSTATE: https://arxiv.org/abs/2601.19221 — prior work on direct recurrent-state diffusion and recurrent-parameter synthesis.
- STAR-LDM: https://arxiv.org/abs/2602.20528 — latent semantic planning; verified author list replaces the outdated list inherited from the old bibliography.
- RWKV-7: https://arxiv.org/abs/2503.14456 — concrete experimental decoder.
- Mamba-2: https://arxiv.org/abs/2405.21060 — state-space duality and efficient sequence modeling.
- Qwen2.5: https://arxiv.org/abs/2412.15115 — autoregressive model-family reference.
- LongBench: https://arxiv.org/abs/2308.14508 — long-context QA protocol.
- RULER: https://arxiv.org/abs/2404.06654 — controlled context-length and task-complexity testing.
- FineWeb: https://arxiv.org/abs/2406.17557 — proposed long-window corpus and optional educational data study.
- Block Diffusion: https://arxiv.org/abs/2503.09573 — distinguishes existing block-diffusion generation from native-memory scheduling.

New Mamba/RULER/corpus-factorial experiments are proposed evaluations, not claims copied from the report. The package makes no new benchmark score, speedup, or GPU training claim.

## Writing guidance
- https://github.com/997042353/ARIS — paper writing and shared writing principles.
- https://github.com/Boom5426/Nature-Paper-Skills — community scientific-writing skill, not an official Nature journal template or endorsement.

## Template
Official conference `.sty` checked against ICLR/Master-Template revision `46ed6f4c6cef5b175dde23639e77d44c3463b230`. See `TEMPLATE_SOURCE.txt` for exact-byte and support-file distinctions. The text area and typography were not reduced to reach nine pages.
