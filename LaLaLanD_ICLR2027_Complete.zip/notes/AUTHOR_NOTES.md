# LaLaLanD — 作者核对说明

## 这次的主线
LaLaLanD 是 generative architecture paper，不是 LATTICE 的 RL paper。主文只把 RWKV 当成实验实现，方法用通用 linear-attention/stateful decoder 表述。

三组实验：
1. 计算与执行调度：同解码器的 dense DiT 控制，AR/SSM 系统对照，真实端到端时间、训练/推理显存及质量；Global、Refresh、Parallel 单独比较。
2. 长文本理解：RACE、LongBench QA、bAbILong、RULER；长输入和长输出是独立变量。
3. 模型能力：复用 CoLA 风格的八任务布局，并为 ELF 保留 OWT 生成/XSum 的重叠协议。

## 来源边界
- Technical_Report.pdf（用户资料）支持旧 global/chunked、fixed-basis 与历史 baseline 名单。旧 PG19/BFCL/14.5x 等数字没有迁移到新表。
- GitHub yuhanlydia/laces-reasoning 的 ef3a7cd034f4795f6c6f42a9afc883fcb64e6879：动态 writer 实现是每层 flattened U、同层各 head 共享 V；state_scale 是现有标量。正文允许一般 gamma_l，附录写出当前实现特例。
- 新的 sealed-start 并行定义是本文提出并要求实验实现的协议，不把当前代码中的 recurrent-state overwrite 自动当作已验证并行正确性。
- 所有性能单元格都为空；没有绘制虚构性能曲线。三张主文图是机制/调度示意。

## 关键科学边界
多 agent 的含义是共享 decoder 权重、各自完整 cache 与 latent plan 的解码 worker。当前没有证据证明每一 latent 是独立的语义思维链或私有事实协商智能体，因此论文称 joint latent planning/coordination，而不是已证实的多智能体推理涌现。

并行文本解码必须隔离全部辅助 state，并且启动 token 不能依赖上一 chunk 的未知输出。本文给出条件和证明，并区分同分布串行/并行调度与改变 lambda 后的质量差异。

S0 的重建目标为 pooled hidden feature，不伪称完整 token 自动重建。预测 clean latent 的共训练样本仍来自 noisy target posterior，不能用它替代 inference prior 的无泄漏评价。

## 写作和后续填表
ARIS 的 paper-writing / paper-write / writing-principles 与 Nature-Paper-Skills 的 scientific-writing 被用于叙事、论点-证据分离和格式组织；没有声称已调用外部 reviewer agent。

CoLA 和 ELF 不是等参或同预训练语料系统。主表必须填 exact checkpoint、参数和数据曝光；原生不支持的任务标 unavailable，不能杜撰复现成绩。

当前完成的是论文重写与排版，不是新的模型训练、GPU评测或仓库代码更新。投稿前应完成 baseline/model revision、训练 token 与 compute、完整 state gradient gate，以及空表内的 matched 结果。
