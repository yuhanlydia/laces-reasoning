# Writing references used

- ARIS skills/paper-writing/SKILL.md, skills/paper-write/SKILL.md, skills/shared-references/writing-principles.md (997042353/ARIS, read on 2026-09-17).
- Nature-Paper-Skills skills/core/scientific-writing/SKILL.md (Boom5426/Nature-Paper-Skills, read on 2026-09-17).

Applied: a single causal story, evidence-to-claim map, concrete verbs, figures before prose, full paragraphs, no invented numerical results, citation checks, compiled layout inspection.
No external reviewer-agent execution is claimed. Nature styling is prose guidance, not the target journal or a claim of endorsement.
