# Figure assets

The first image-generation call produced `ai_method_concept.png`, an author-facing concept image. It is not the manuscript's technical source of truth: generated labels, dimensions and fine text can be unreliable.

The manuscript uses three separately compiled, editable TikZ/PDF figures:
- `interfaces`: token AR, dense diffusion, and compact native-memory planning.
- `overview`: training-only variational feature bottleneck; conditional bidirectional linear-attention denoiser; input-dependent U/V state writer; global and parallel worker paths.
- `schedule`: serialized and concurrent evaluation of exactly the same sealed-start computation.

Known launch anchors and separate complete caches are shown explicitly. No empirical curve, speedup or accuracy has been drawn without data. Editable vectors are included so final visual changes need not involve raster retouching.
