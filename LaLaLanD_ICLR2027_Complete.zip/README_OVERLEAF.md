# LaLaLanD — complete ICLR-style manuscript project

Main file: `main.tex`. Compiler: pdfLaTeX. Bibliography: BibTeX.

Upload this ZIP as a new Overleaf project and set `main.tex` as the main document. All manuscript sections and appendices are in that file. The three figures are already compiled to PDF; their editable TikZ sources are in `figures/`.

The checked build has **9 pages of main text**, followed by reference/disclosure pages and the appendix. This is a research manuscript draft with deliberately **blank numerical result cells**. It is not a completed experimental submission.

## Contents
- `main.tex`, `references.bib`, `main.bbl` and compiled `main.pdf`.
- Official ICLR 2027 conference style, plus bibliography/package support from the supplied project. Exact provenance is in `TEMPLATE_SOURCE.txt`.
- `figures/interfaces.pdf`, `figures/overview.pdf`, `figures/schedule.pdf`, and matching `.tex` sources.
- `notes/AUTHOR_NOTES.md`: source/claim boundaries and the key experimental decisions.
- `source/ai_method_concept.png`: optional AI-generated concept artwork; **not** included as scientific evidence or used as the final technical diagram.
- `validation/BUILD_REPORT.json`: compile, citation and page-count checks.

## Build locally
```sh
bash build.sh
```
The existing figure PDFs are sufficient for the manuscript build. To edit the figures, compile their standalone `.tex` files first.

Do not uncomment `\iclrfinalcopy` for an anonymous submission. Standard LaTeX packages and fonts come from TeX Live/Overleaf; no font binaries are distributed here.

Remove `notes/`, `source/`, and `validation/` when assembling an anonymous supplemental archive if their development provenance is not intended for reviewers.
