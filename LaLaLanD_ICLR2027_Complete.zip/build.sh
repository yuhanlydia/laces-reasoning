#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v bibtex >/dev/null 2>&1; then BIB=bibtex
elif command -v bibtex.original >/dev/null 2>&1; then BIB=bibtex.original
else echo 'BibTeX is required; install a standard TeX Live distribution.' >&2; exit 1
fi
pdflatex -interaction=nonstopmode -halt-on-error main.tex
"$BIB" main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
